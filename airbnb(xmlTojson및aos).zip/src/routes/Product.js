import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductSection from '../components/ProductSection';

const Product = ({active, onSelect}) => {
  return (
    <div>
      <Header onSelect={onSelect} />
      <ProductSection active={active} onSelect={onSelect} />
      <Footer />
    </div>
  );
};

export default Product;