import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import HomeSection from '../components/HomeSection';

const Home = ({onSelect}) => {
  return (
    <div>
      <Header onSelect={onSelect} />
      <HomeSection />
      <Footer />
    </div>
  );
};

export default Home;