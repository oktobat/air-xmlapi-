import React from 'react';
import Header from '../components/Header'
import Footer from '../components/Footer';
import CommunitySection from '../components/CommunitySection';

const Community = ({onSelect}) => {
  return (
    <div>
      <Header onSelect={onSelect} />
      <CommunitySection />
      <Footer />
    </div>
  );
};

export default Community;