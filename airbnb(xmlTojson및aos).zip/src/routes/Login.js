import React from 'react';
import MemberTemp from '../components/MemberTemp';

const Login = ({onSelect}) => {
  return (
    <MemberTemp onSelect={onSelect} type="login"></MemberTemp>
  );
};

export default Login;