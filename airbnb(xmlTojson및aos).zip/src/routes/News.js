import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import NewsSection from '../components/NewsSection';

const News = ({onSelect}) => {
  return (
    <div>
      <Header onSelect={onSelect} />
      <NewsSection />
      <Footer />
    </div>
  );
};

export default News;