import React, {useState} from 'react';
import {HashRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './routes/Home';
import Product from './routes/Product';
import News from './routes/News';
import Community from './routes/Community';
import About from './routes/About';
import Login from './routes/Login';
import Join from './routes/Join';

const App = () => {

  const [active, setActive] = useState(0)

  const onSelect = (id) => {
      setActive(id)
  }

  return (
    <Router>
      <Routes>
        <Route path="/" element={ <Home onSelect={onSelect} /> } />
        <Route path="/product" element={ <Product active={active} onSelect={onSelect} /> } />
        <Route path="/news" element={ <News onSelect={onSelect} /> } />
        <Route path="/community" element={ <Community onSelect={onSelect} /> } />
        <Route path="/about" element={ <About onSelect={onSelect} /> } />
        <Route path="/login" element={ <Login onSelect={onSelect} /> } />
        <Route path="/join" element={ <Join onSelect={onSelect} /> } />
      </Routes>
    </Router>
  );
};

export default App;