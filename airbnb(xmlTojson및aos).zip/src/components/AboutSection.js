import React from 'react';
import styled from 'styled-components';

const AboutSectionBlock = styled.div`
    border-top:107px solid blue;
    .row { padding-top:100px }
`;

const AboutSection = () => {
  return (
    <AboutSectionBlock>
        <div className="row">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d50667.628097623114!2d126.79316026049727!3d37.46717295095834!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357b6365aa8595d1%3A0xf15778b9701a6f82!2z7ZWY67KE65287J24M-uLqOyngA!5e0!3m2!1sko!2skr!4v1647496997126!5m2!1sko!2skr" width="100%" height="450" style={{border:0}} title="구글맵" />
        </div>
    </AboutSectionBlock>
  );
};

export default AboutSection;