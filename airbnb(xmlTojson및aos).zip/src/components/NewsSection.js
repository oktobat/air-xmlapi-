import React, {useEffect, useState} from 'react';
import styled from 'styled-components';
import axios from 'axios';
import { AiOutlineLoading3Quarters } from 'react-icons/ai';
import XMLParser from "react-xml-parser";

const NewsSectionBlock = styled.div`
    border-top:107px solid pink;
    .load { 
      display:flex; justify-content:center; align-items:center; min-height:70vh; 
      font-size:100px; 
      .loadIcon { animation:loadSpin 5s linear infinite; }
      @keyframes loadSpin {
        0% { transform:rotate(0deg) }
        100% { transform:rotate(3turn) }
      }
    }
`;

const CategoryBlock = styled.div`
    display:flex; margin:50px 0 30px; justify-content:center; 
    div { background:#ddd; padding:10px 20px; border-radius:10px; margin:50px 20px; cursor:pointer }
`;

const ArticleBlock = styled.div`
    display:flex; flex-wrap:wrap; justify-content:space-between;
    .article { width:48%; display:flex; align-items:flex-start; margin:20px 0; 
      div { p:nth-child(1) { font-size:20px; margin-bottom:10px  } }
      img { width:200px; margin-right:20px }
    }
`;

const tabTit = [
  { name:'all', text:'전체보기' },
  { name:'business', text:'비즈니스' },
  { name:'entertainment', text:'엔터테인먼트' },
  { name:'health', text:'건강' },
  { name:'science', text:'과학' },
  { name:'sports', text:'스포츠' },
  { name:'technology', text:'기술' }
]

const NewsSection = () => {

  const [articles, setArticles] = useState([])
  const [category, setCategory] = useState('all')
  const [loading, setLoading] = useState(false)

  const onChange = (name) => {
      setCategory(name)
  }

  function parseStr(xmldata){
    const dataArr = new XMLParser().parseFromString(xmldata).children;
    console.log(dataArr)
    const jsondata = dataArr[1].children[3]
    return jsondata
  }

  const getNews = async ()=>{
    // const query = category === 'all' ? '' : `&category=${category}`
    // const response = await axios.get(`https://newsapi.org/v2/top-headlines?country=kr${query}&apiKey=11ba08dfbd7e4f3c83ac93b27aa1dcb7`)
    const response = await axios.get(`https://mykim.herokuapp.com/http://apis.data.go.kr/5530000/hs-coronavirus-coronic/getHsCoronavirusCoronic?serviceKey=vyiziQ9gC5h5qUZI1Fbf6oRT5XU0blUCJUHJmbyeqGCnkK3gg010CYY2okg28Vhpfe7ThjtvJNCECLUhUEESiw%3D%3D&pageNo=1&numOfRows=10`)
    setLoading(true)
    const xmldata = response.data
    const jdata = parseStr(xmldata)
    console.log(jdata)
    setArticles(jdata.children)
  }

  useEffect(
    ()=>{ getNews() },
    [category]
  )

  if (!loading) {
     return ( 
      <NewsSectionBlock>
         <div className="load">
           <AiOutlineLoading3Quarters className="loadIcon" />
         </div>
      </NewsSectionBlock>  
     );
  } else {

   return (
    <NewsSectionBlock>
      <div className="row">
          <CategoryBlock>
            { tabTit.map( (data, index)=>( <div key={index} onClick={()=>onChange(data.name)} style={{ background: category===data.name && '#000', color:category===data.name && '#fff' }}>{data.text}</div>  ) ) }
          </CategoryBlock>
          <ArticleBlock>
              { articles.map( (data, index)=>( 
                  <div className="article" key={index}>
                    {data.children[2].value}
                    {data.children[13].value}
               </div> ) ) }
          </ArticleBlock>
      </div>
    </NewsSectionBlock>
  );
}
};

export default NewsSection;