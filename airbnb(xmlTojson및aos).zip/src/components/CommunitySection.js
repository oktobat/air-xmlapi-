import React from 'react';
import styled from 'styled-components';

const CommunitySectionBlock = styled.div`
    border-top:107px solid orange;
`;

const CommunitySection = () => {
  return (
    <CommunitySectionBlock>
      
    </CommunitySectionBlock>
  );
};

export default CommunitySection;